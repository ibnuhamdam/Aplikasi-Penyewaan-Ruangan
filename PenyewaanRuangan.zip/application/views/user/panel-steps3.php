<div class="step">
        <div class="container">
            <div class="row">
                <div class="col-md-3 offset-md-1 steps" id="daftar" style="boder-left:1px !important;">
                    <div class="row">
                        <div class="col-md-10 pendataan" >
                            <p class="">1  pendaftaran </p>
                        </div>
                        <div class="col-md-2">
                            <div class="segitiga" id="segitigad">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 steps" id="setuju">
                    <div class="row">
                            <div class="col-md-10 pendataan">
                                <p class="">2  penyetujuan </p>
                            </div>
                            <div class="col-md-2">
                                <div class="segitiga" id="segitigas">
                                </div>
                            </div>
                    </div>
                </div>
                <div class="col-md-3 activestep">
                    <div class="tu">
                        <p class="text-white">3 Pembayaran</p>
                    </div>
                </div>
            </div>
        </div>
        
    </div>