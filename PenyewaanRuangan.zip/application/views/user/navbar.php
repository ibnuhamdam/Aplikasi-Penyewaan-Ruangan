<nav class="navbar navbar-expand-lg ">
  <div class="navbar-brand">
  <a class="navbar-brand logo" href="#"> <p> BTP</p></a>
  </div>
  <button class="navbar-toggler"  type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon " style="color:white;"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo site_url('controller_utama/index'); ?>">Beranda <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Inovasi Kami</a>
      </li>
      <li class="nav-item" style="border:1px solid white;">
        <a class="nav-link" href="<?php echo site_url('controller_utama/index'); ?>">Layanan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Berita</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Kontak</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Startup Corner</a>
      </li>
    </ul>
  </div>
</nav>
